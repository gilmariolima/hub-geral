@echo off
title Scripts Unificados - servidor local (porta 3000)
cd /d "%~dp0"
set "BAT=%~f0"
echo.
echo  ================================================
echo    Scripts Unificados - servidor local
echo    Pasta: %~dp0
echo    Endereco: http://localhost:3000/loader.js
echo  ================================================
echo.
echo  Deixe esta janela aberta enquanto usa o SmartBus / ChatPro / Tallos.
echo  Para desligar, feche a janela (ou Ctrl+C).
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=[IO.File]::ReadAllText($env:BAT); $m='#'+'#PS#'+'#'; iex $f.Substring($f.LastIndexOf($m)+$m.Length)"
echo.
pause
exit /b

##PS##
$porta = 3000
$raiz  = [IO.Path]::GetFullPath((Split-Path -Parent $env:BAT)).TrimEnd('\') + '\'

$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$porta/")
$l.Prefixes.Add("http://127.0.0.1:$porta/")
try { $l.Start() } catch {
    Write-Host " ERRO: nao consegui abrir a porta $porta." -ForegroundColor Red
    Write-Host " Provavelmente o servidor ja esta aberto em outra janela." -ForegroundColor Red
    return
}
Write-Host " Servidor ligado. Aguardando o navegador..." -ForegroundColor Green
Write-Host ""

try {
    while ($l.IsListening) {
        $t = $l.GetContextAsync()
        while (-not $t.AsyncWaitHandle.WaitOne(500)) { }
        $ctx = $t.Result
        $res = $ctx.Response
        $res.Headers.Add('Access-Control-Allow-Origin', '*')
        $res.Headers.Add('Cache-Control', 'no-store')

        $nome = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
        if ($nome -eq '') { $nome = 'unificado.js' }
        $arq = [IO.Path]::GetFullPath((Join-Path $raiz $nome))
        $hora = Get-Date -Format 'HH:mm:ss'

        if ($arq.StartsWith($raiz, [StringComparison]::OrdinalIgnoreCase) -and
            $arq.EndsWith('.js', [StringComparison]::OrdinalIgnoreCase) -and
            (Test-Path -LiteralPath $arq -PathType Leaf)) {
            $bytes = [IO.File]::ReadAllBytes($arq)
            $res.ContentType = 'application/javascript; charset=utf-8'
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            Write-Host " [$hora] enviado $nome" -ForegroundColor Gray
        } else {
            $res.StatusCode = 404
            Write-Host " [$hora] nao encontrado: $nome" -ForegroundColor Yellow
        }
        $res.Close()
    }
} finally {
    $l.Stop()
}
