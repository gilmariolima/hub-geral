// loader.js — servido pelo "Iniciar Scripts.bat" em http://localhost:3000/loader.js
// É carregado pelo Gilvan Loader do Tampermonkey (que injeta uma tag <script> na página).
// Como numa tag <script> não existem as funções GM_* do Tampermonkey, aqui criamos
// substitutos e depois carregamos o unificado.js.
(function () {
    'use strict';

    if (window.__unificadoLoader) return;
    window.__unificadoLoader = true;

    // Só roda nos sites do script (o Gilvan Loader carrega em todos os sites)
    var h = location.hostname;
    var siteOk = /(^|\.)smarttravelit\.com$/.test(h) ||
                 h === 'app.chatpro.com.br' ||
                 /(^|\.)tallos\.com\.br$/.test(h);
    if (!siteOk) return;

    var BASE = 'http://localhost:3000';
    try { if (document.currentScript) BASE = new URL(document.currentScript.src).origin; } catch (e) {}

    // ---------- GM_getValue / GM_setValue -> localStorage ----------
    var PREFIXO = 'unificado:';
    window.GM_getValue = function (chave, padrao) {
        try {
            var v = localStorage.getItem(PREFIXO + chave);
            return v === null ? padrao : JSON.parse(v);
        } catch (e) { return padrao; }
    };
    window.GM_setValue = function (chave, valor) {
        try { localStorage.setItem(PREFIXO + chave, JSON.stringify(valor)); } catch (e) {}
    };
    window.unsafeWindow = window;

    // ---------- Menu do Tampermonkey -> botão flutuante ⚙ ----------
    var comandos = {};
    var proximoId = 1;
    var painel, botao, lista, agendado = false;

    window.GM_registerMenuCommand = function (nome, fn) {
        var id = proximoId++;
        comandos[id] = { nome: nome, fn: fn };
        renderizar();
        return id;
    };
    window.GM_unregisterMenuCommand = function (id) {
        delete comandos[id];
        renderizar();
    };

    function renderizar() {
        if (agendado) return;
        agendado = true;
        setTimeout(function () { agendado = false; desenhar(); }, 0);
    }

    function criarPainel() {
        if (painel || !document.body) return;
        painel = document.createElement('div');
        painel.id = 'unificado-menu';
        painel.setAttribute('data-html2canvas-ignore', 'true');
        painel.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:2147483647;font:13px Arial,sans-serif;';

        botao = document.createElement('button');
        botao.textContent = '⚙';
        botao.title = 'Scripts Unificados — ligar/desligar módulos';
        botao.style.cssText = 'width:30px;height:30px;border-radius:50%;border:none;cursor:pointer;' +
            'background:#333;color:#fff;font-size:16px;opacity:.45;box-shadow:0 2px 6px rgba(0,0,0,.3);';
        botao.onmouseenter = function () { botao.style.opacity = '1'; };
        botao.onmouseleave = function () { botao.style.opacity = '.45'; };

        lista = document.createElement('div');
        lista.style.cssText = 'display:none;position:absolute;left:0;bottom:36px;min-width:300px;background:#fff;color:#222;' +
            'border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.25);padding:6px;';

        botao.onclick = function (e) {
            e.stopPropagation();
            lista.style.display = lista.style.display === 'none' ? 'block' : 'none';
        };
        document.addEventListener('click', function (e) {
            if (lista && !painel.contains(e.target)) lista.style.display = 'none';
        });

        painel.appendChild(lista);
        painel.appendChild(botao);
        document.body.appendChild(painel);
    }

    function desenhar() {
        if (!document.body) {
            document.addEventListener('DOMContentLoaded', desenhar, { once: true });
            return;
        }
        criarPainel();
        lista.innerHTML = '';
        Object.keys(comandos).forEach(function (id) {
            var c = comandos[id];
            var item = document.createElement('div');
            item.textContent = c.nome;
            item.style.cssText = 'padding:7px 9px;border-radius:5px;cursor:pointer;white-space:nowrap;';
            item.onmouseenter = function () { item.style.background = '#eee'; };
            item.onmouseleave = function () { item.style.background = ''; };
            item.onclick = function (e) {
                e.stopPropagation();
                try { c.fn(); } catch (err) { console.error('[Unificado] erro no menu', err); }
            };
            lista.appendChild(item);
        });
    }

    // ---------- Carrega o script principal ----------
    var s = document.createElement('script');
    s.charset = 'utf-8';
    s.src = BASE + '/unificado.js?v=' + Date.now();
    s.onload = function () { console.log('[Unificado] carregado de', BASE); };
    s.onerror = function () { console.warn('[Unificado] não consegui carregar unificado.js de', BASE); };
    (document.head || document.documentElement).appendChild(s);
})();
