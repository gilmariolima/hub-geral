// ==UserScript==
// @name         Scripts Unificados (SmartBus + ChatPro/Tallos)
// @namespace    gilmario.unificado
// @version      1.0.0
// @description  Junta: Barras e mensagens, Área de clique e cópia, Copiar Link, Fast Loading, Horário + Serviço, Print da Reserva e Print dos horários/remarcações
// @match        *://*.smarttravelit.com/*
// @match        *://app.chatpro.com.br/*
// @match        *://*.tallos.com.br/*
// @require      https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_unregisterMenuCommand
// ==/UserScript==

(function () {
    'use strict';

    // =========================================================================
    // MINI-HUB — substitui o registrarModulo() do Painel de Scripts.
    // Cada módulo pode ser ligado/desligado pelo menu do Tampermonkey
    // (ícone da extensão), sem recarregar a página. A escolha fica salva.
    // =========================================================================
    const modulos = [];
    const SITE_ATUAL = location.hostname.includes('smarttravelit.com') ? 'smartbus' : 'chat';
    const CHAVE_ESTADO = 'modulos_ativos';
    let idsMenu = [];

    function lerEstado() {
        try { return GM_getValue(CHAVE_ESTADO, {}) || {}; } catch (e) { return {}; }
    }

    function salvarEstado() {
        const estado = {};
        modulos.forEach(m => { estado[m.id] = !!m._querLigado; });
        try { GM_setValue(CHAVE_ESTADO, { ...lerEstado(), ...estado }); } catch (e) {}
    }

    // site: 'smartbus' | 'chat'
    // cedo: true = roda já no document-start (Fast Loading); os demais esperam o <body>
    function registrarModulo(mod, site, cedo = false) {
        if (site !== SITE_ATUAL) return;
        const estado = lerEstado();
        mod._ativo = false;
        mod._cedo = cedo;
        mod._querLigado = mod.id in estado ? !!estado[mod.id] : mod.defaultOn !== false;
        modulos.push(mod);
    }

    function ligar(m) {
        if (m._ativo) return;
        m._ativo = true; // antes do init: o Copiar Link confere isso no clique
        try { m.init(); } catch (e) { m._ativo = false; console.error('[Unificado] erro ao ligar', m.id, e); }
    }

    function desligar(m) {
        if (!m._ativo) return;
        m._ativo = false;
        try { m.destroy(); } catch (e) { console.error('[Unificado] erro ao desligar', m.id, e); }
    }

    function quandoTiverBody(cb) {
        if (document.body) return cb();
        document.addEventListener('DOMContentLoaded', cb, { once: true });
    }

    function montarMenu() {
        if (typeof GM_registerMenuCommand !== 'function') return;
        if (typeof GM_unregisterMenuCommand === 'function') {
            idsMenu.forEach(id => { try { GM_unregisterMenuCommand(id); } catch (e) {} });
        }
        idsMenu = modulos.map(m => GM_registerMenuCommand(
            `${m._querLigado ? '✅' : '⬜'} ${m.name}`,
            () => {
                m._querLigado = !m._querLigado;
                salvarEstado();
                if (m._querLigado) quandoTiverBody(() => ligar(m)); else desligar(m);
                montarMenu();
            }
        ));
    }

    function iniciarTudo() {
        modulos.filter(m => m._cedo && m._querLigado).forEach(ligar);
        quandoTiverBody(() => modulos.filter(m => !m._cedo && m._querLigado).forEach(ligar));
        montarMenu();
    }

    // =========================================================================
    // MÓDULO — Barras e mensagens (ChatPro / Tallos)
    // =========================================================================
    function criarModuloBarrasMensagens() {
        const GRUPO_ID = 'tallos-botoes-mensagens';
        const ESTILO_ID = 'tallos-botoes-mensagens-style';
        const FOOTER_SELECTOR = 'footer.chat-messages-footer';
        const EDITOR_SELECTORS = ['.ql-editor', '[contenteditable="true"]', 'textarea', 'input[type="text"]', 'input:not([type])'];
        const SUGESTAO_SELECTOR = 'button.suggestion-button.tg-btn_tertiary[title="Ver sugestão de resposta"]';

        const MENSAGENS = [
            { icon: '🤖', title: 'SAUDACAO DIRETA', texto: `Olá, boa noite.
Tudo bem?
Como posso ajudar?` },

            { icon: '🚌', title: 'REMARCACAO', texto: `📌 Para remarcar, preciso que você envie:

📄 Bilhete em PDF ou foto;
🪪 Foto do RG ou CNH do passageiro;
🕒 Nova data e horário desejados.
━━━━━━━━━━━━━━
⚠️ REGRAS GERAIS:
• A partir de 3h antes do embarque, há multa de 20%. Após esse prazo, ou se o embarque não for realizado, a remarcação só pode ser feita para o MESMO TRECHO;
• Se já houve remarcação com multa, ela será aplicada novamente;
• Se a nova passagem for mais cara, será cobrada a diferença;
• Pagamento somente via PIX CNPJ;
• Há taxa de conveniência na plataforma.
━━━━━
⚠️ Regras para viagens intermunicipais:
📍 RJ: alterações somente até 1h antes do embarque. Após isso, o bilhete perde a validade.
📍 MG: solicitação com pelo menos 12h de antecedência.
📍 SP: remarcação ou cancelamento com pelo menos 8h de antecedência, conforme Art. 93 do Decreto nº 29.913.

Qualquer dúvida, estou à disposição!` },

            { icon: '✈', title: 'TRECHO', texto: `Por gentileza, poderia informar as seguintes informações sobre a sua viagem:

Origem:
Destino:
Data:

*Informe se a viagem tem volta*` },

        { icon: '🕛', title: 'HORARIO', texto: `Segue os horários disponíveis
Dá uma olhadinha nas opções acima e me diz qual horário você prefere.` },

            { icon: 'C', title: 'CINZAS', texto: `Poltronas Cinzas livres, qual deseja?` },

            { icon: '💺', title: 'POLTRONAS', texto: `💺 Mapa de Poltronas

🟩 Verde: poltronas sugeridas / opções de escolha
⬜ Cinza: poltronas disponíveis
🟥 Vermelho: poltronas vendidas / ocupadas
🟧 Laranja: poltronas pendentes / em processo de venda

Por gentileza, escolha a(s) poltrona(s) desejada(s) para dar continuidade ao atendimento.` },

            { icon: '🪪', title: 'DADOS', texto: `Dados do Passageiro -
Nome:
RG:
CPF:
Data de Nascimento:` },

            { icon: '⚠️', title: 'CONFERE', texto: `*Por gentileza, poderia conferir se todas as informações da sua reserva estão corretas? (Passageiro, Trecho, Data, horário e poltrona*)` },

            { icon: 'PG', title: 'PAGAMENTO', texto: `Qual será a forma de pagamento?` },


            { icon: '🔗', title: 'LINK', texto: `Segue link para pagamentos via PIX e cartão, lembrando que para pagamentos via cartão de crédito, os dados do comprador são referentes ao proprietário do cartão.` },

            {
                icon: '🔗',
                title: 'CV',
                texto: `Segue link para pagamento via Cartão de crédito e PIX:

Passo a passo. (CARTÃO)
1. Preencher os dados em comprador e pagamento referente ao titular do cartão.
2. Gere um novo virtual ou tente com um cartão diferente dos usados anteriormente.
3. Limpar os dados ou abrir uma nova guia no navegador.
4. CEP da fatura, preencher referente ao CEP em que foi feito o pedido do cartão (físico).
5. Ao solicitar o token de confirmação da compra, verificar e aceitar no banco.`
            },

            { icon: '❖', title: 'PIX', texto: `Segue abaixo os dados bancários para transferência via PIX!

Valor: R$

Nome: VALE VIAGENS/ ANTÔNIO CLERVES
CHAVE CNPJ: 18.826.066/0001-09

Emissão da passagem mediante ao envio do comprovante de pagamento!` },

            { icon: '🏁', title: 'COMPRA FIM', texto: `Sua compra foi efetuada com sucesso!
Peço que verifique o e-mail cadastrado na hora da compra (caixa de entrada e spam) por gentileza, pode levar ate 15 minutos para a passagens chegarem no e-mail!

Posso ajudar em mais alguma coisa?` },

            { icon: '🔎', title: 'VERIFICA', texto: `Confira se os dados do seu bilhete estão corretos
Verifique trecho, data, horário e dados pessoais.` },

            { icon: '🤔', title: 'AGRADECE', texto: `Agradeço o contato, confiança e preferência em nosso trabalho. Ficamos à disposição para lhe atender posteriormente.

Boa noite e uma excelente viagem.` },

            { icon: '🛂', title: 'EMBARQUE', texto: `Basta mostrar o PDF do bilhete ao motorista pela tela do celular junto com o documento original físico com foto, mas caso deseje imprimir os bilhetes, basta se dirigir até o guichê e imprimir o bilhete.` },

            { icon: '☎️', title: 'SAC', texto: `SAC: 0800 728 1992 - Opção 1, em seguida opção 9 e opção 1 novamente.` },

    

            { icon: '📁', title: 'DOCUMENTO', texto: `Me envia o bilhete e documento do titular por favor` },
        ];

        let observer = null;

        function garantirEstilo() {
            if (document.getElementById(ESTILO_ID)) return;
            const style = document.createElement('style');
            style.id = ESTILO_ID;
            style.textContent = `
                footer.chat-messages-footer.tm-com-barra { flex-wrap: wrap !important; }
                #${GRUPO_ID} {
                    flex: 0 0 100%; order: -1; width: 100%;
                    display: flex; flex-wrap: wrap; gap: 3px;
                    padding: 0 0 6px 0; margin: 0;
                }
                #${GRUPO_ID} button { position: relative; }
                #${GRUPO_ID} button::after {
                    content: attr(data-tooltip);
                    position: absolute; top: -34px; left: 50%;
                    transform: translateX(-50%);
                    background: #000; color: #fff;
                    padding: 4px 8px; border-radius: 6px;
                    font-size: 11px; white-space: nowrap;
                    opacity: 0; pointer-events: none;
                    transition: opacity .15s ease; z-index: 9999;
                }
                #${GRUPO_ID} button:hover::after { opacity: 1; }
            `;
            document.head.appendChild(style);
        }

        function noChat() {
            // ChatPro: /chat/<id>  |  Tallos: /app/chat
            return /\/chat(\/|$)/.test(location.pathname);
        }

        function esconderSugestaoResposta() {
            document.querySelectorAll(SUGESTAO_SELECTOR).forEach(btn => { btn.style.display = 'none'; });
        }

        function escaparHtml(s) {
            return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        function acharEditor(footer) {
            for (const sel of EDITOR_SELECTORS) {
                const el = footer.querySelector(sel);
                if (el && !el.closest('#' + GRUPO_ID)) return el;
            }
            return null;
        }

        function inserirTexto(texto, btn) {
            const footer = document.querySelector(FOOTER_SELECTOR);
            const editor = footer && acharEditor(footer);
            if (!editor) return;

            texto = texto.replace(/\r/g, '');

            if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
                // campo nativo (React/Vue): usa o setter do protótipo para o framework perceber
                const proto = editor.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                Object.getOwnPropertyDescriptor(proto, 'value').set.call(editor, texto);
                editor.dispatchEvent(new Event('input', { bubbles: true }));
                editor.dispatchEvent(new Event('change', { bubbles: true }));
            } else if (editor.classList.contains('ql-editor')) {
                // editor Quill
                editor.innerHTML = texto
                    .split('\n')
                    .map(l => l.trim() === '' ? '<p><br></p>' : `<p>${escaparHtml(l)}</p>`)
                    .join('');
                editor.dispatchEvent(new Event('input', { bubbles: true }));
            } else {
                // contenteditable genérico: substitui o conteúdo como se fosse digitado
                editor.focus();
                const sel = window.getSelection();
                const range = document.createRange();
                range.selectNodeContents(editor);
                sel.removeAllRanges();
                sel.addRange(range);
                if (!document.execCommand('insertText', false, texto)) {
                    editor.innerText = texto;
                    editor.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }

            editor.focus();

            const original = btn.innerHTML;
            btn.innerHTML = '✅';
            setTimeout(() => { btn.innerHTML = original; }, 800);
        }

        function inserirBotoes() {
            const footer = document.querySelector(FOOTER_SELECTOR);
            if (!footer || footer.querySelector('#' + GRUPO_ID)) return;

            const grupo = document.createElement('div');
            grupo.id = GRUPO_ID;

            MENSAGENS.forEach(msg => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.innerHTML = msg.icon.trim();
                btn.setAttribute('data-tooltip', msg.title);
                btn.style.cssText = `
                    width:28px;height:28px;background:transparent;border:none;
                    border-radius:6px;font-size:16px;cursor:pointer;opacity:.75;
                    display:flex;align-items:center;justify-content:center;padding:0;
                `;
                btn.onmouseenter = () => { btn.style.opacity = '1'; };
                btn.onmouseleave = () => { btn.style.opacity = '.75'; };
                // mousedown + preventDefault: o clique não tira o foco do campo de mensagem
                btn.onmousedown = e => e.preventDefault();
                btn.onclick = () => inserirTexto(msg.texto, btn);
                grupo.appendChild(btn);
            });

            // entra como primeiro filho do footer, ocupando a linha toda acima do campo
            footer.classList.add('tm-com-barra');
            footer.insertBefore(grupo, footer.firstChild);
        }

        function rodar() {
            if (!noChat()) return;          // site SPA: confere a rota a cada mudança
            esconderSugestaoResposta();
            inserirBotoes();
        }

        return {
            id: 'chat_barras_mensagens',
            name: 'CHAT - Barras e mensagens',
            defaultOn: true,

            init() {
                garantirEstilo();
                observer = new MutationObserver(rodar);
                observer.observe(document.body, { childList: true, subtree: true });
                rodar();
            },

            destroy() {
                observer?.disconnect();
                observer = null;
                document.getElementById(GRUPO_ID)?.remove();
                document.getElementById(ESTILO_ID)?.remove();
                document.querySelectorAll('footer.tm-com-barra').forEach(f => f.classList.remove('tm-com-barra'));
                document.querySelectorAll(SUGESTAO_SELECTOR).forEach(btn => { btn.style.display = ''; });
            }
        };
    }

    // =========================================================================
    // MÓDULO — Área de clique e cópia (SmartBus/Guanabara)
    // =========================================================================
    function criarModuloSmartbusCopiarClique() {
        // guarda cada elemento + handler para o destroy() conseguir
        // remover o listener e reverter o estilo
        const elementosAtivos = [];

        function isReserva() {
            return document.querySelector('.page-title')?.textContent?.trim() === 'Reserva';
        }

        function normalizarDocumento(texto) {
            if (texto.includes('-')) {
                return texto.split('-').slice(1).join('-').trim();
            }
            return texto.trim();
        }

        function aplicarCliqueCopiar(el, tipo = 'normal') {
            if (!el || el.dataset.copiarAtivo) return;
            let texto = el.textContent?.trim();
            if (!texto) return;
            if (tipo === 'documento') {
                texto = normalizarDocumento(texto);
            }

            el.dataset.copiarAtivo = 'true';
            el.style.border = '1px dashed #3b82f6';
            el.style.padding = '4px 10px';
            el.style.borderRadius = '6px';
            el.style.cursor = 'pointer';
            el.style.transition = 'border-color .2s ease, background-color .2s ease';
            el.title = 'Clique para copiar';

            const handler = (e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(texto);
                el.style.borderColor = 'green';
                el.style.backgroundColor = '#e6f4ea';
                setTimeout(() => {
                    el.style.borderColor = '#3b82f6';
                    el.style.backgroundColor = 'transparent';
                }, 1200);
            };

            el.addEventListener('click', handler);
            elementosAtivos.push({ el, handler });
        }

        function aplicar() {
            if (!isReserva()) return;

            document.querySelectorAll('.col-coupon-service-title b').forEach(el => aplicarCliqueCopiar(el));

            document.querySelectorAll('.col-coupon-service b').forEach(b => {
                if (/\d{2}\/\d{2}\/\d{4}/.test(b.textContent)) {
                    aplicarCliqueCopiar(b);
                }
            });

            const tituloPassageiros = [...document.querySelectorAll('h3,h4')]
                .find(h => h.textContent.trim() === 'Passageiros');

            if (tituloPassageiros) {
                const bloco = tituloPassageiros.closest('.card, .card-body, .card-coupon-area');
                bloco?.querySelectorAll('tbody tr').forEach(tr => {
                    const tds = tr.querySelectorAll('td');
                    aplicarCliqueCopiar(tds[1]);
                    aplicarCliqueCopiar(tds[2], 'documento');
                    aplicarCliqueCopiar(tds[4]);
                });
            }

            document.querySelectorAll('.card-coupon-actions').forEach(card => {
                [...card.querySelectorAll('*')].forEach(el => {
                    if (el.textContent?.trim() === 'E-mail') {
                        const email = el.nextElementSibling;
                        if (email) aplicarCliqueCopiar(email);
                    }
                });
            });
        }

        let observer = null;

        return {
            id: 'smartbus_copiar_clique',
            name: 'SMART BUS - Area de clique e copia',
            defaultOn: true,

            init() {
                observer = new MutationObserver(aplicar);
                observer.observe(document.body, { childList: true, subtree: true });
                aplicar();
            },

            destroy() {
                if (observer) {
                    observer.disconnect();
                    observer = null;
                }

                elementosAtivos.forEach(({ el, handler }) => {
                    el.removeEventListener('click', handler);
                    el.style.border = '';
                    el.style.padding = '';
                    el.style.borderRadius = '';
                    el.style.cursor = '';
                    el.style.transition = '';
                    el.style.borderColor = '';
                    el.style.backgroundColor = '';
                    el.title = '';
                    delete el.dataset.copiarAtivo;
                });
                elementosAtivos.length = 0;
            }
        };
    }

    // =========================================================================
    // MÓDULO — Copiar Link (modal de compartilhamento)
    // =========================================================================
    function criarModuloCopiarLink() {
        const ESTILO_ID = 'tmm-copiar-link-style';
        let observer = null;

        function garantirEstilo() {
            if (document.getElementById(ESTILO_ID)) return;
            const style = document.createElement('style');
            style.id = ESTILO_ID;
            style.textContent = `
                .smart-copy-wrapper {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .smart-copy-wrapper input[type="text"] {
                    flex: 1;
                }
                .smart-copy-btn {
                    padding: 6px 14px;
                    background: #2563eb;
                    color: #fff;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 13px;
                    white-space: nowrap;
                    transition: background-color .2s ease;
                }
                .smart-copy-btn:hover {
                    background: #3b82f6;
                }
            `;
            document.head.appendChild(style);
        }

        // verifica se o módulo com esse id está ativo no mini-hub
        function isEnabled(id) {
            const mod = modulos.find(m => m.id === id);
            return mod ? !!mod._ativo : false;
        }

        // Troca o texto do botão temporariamente (feedback de "copiado") e depois volta ao original
        function setCopiedState(btn, textoTemporario, textoOriginal, duracaoMs = 1500) {
            btn.textContent = textoTemporario;
            setTimeout(() => {
                btn.textContent = textoOriginal;
            }, duracaoMs);
        }

        function moverBotaoCopiarLink() {
            const modal = document.querySelector('.div-lightbox-content');
            if (!modal) return;
            const input = modal.querySelector('input[type="text"]');
            if (!input) return;
            let wrapper = input.closest('.smart-copy-wrapper');
            let btn = wrapper?.querySelector('.smart-copy-btn');
            if (!wrapper) {
                wrapper = document.createElement('div');
                wrapper.className = 'smart-copy-wrapper';
                input.parentNode.insertBefore(wrapper, input);
                wrapper.appendChild(input);
            }
            if (!btn) {
                btn = document.createElement('button');
                btn.className = 'smart-copy-btn';
                btn.textContent = 'Copiar link';
                btn.onclick = async () => {
                    if (!isEnabled('copyLink')) return;
                    try {
                        await navigator.clipboard.writeText(input.value || '');
                        setCopiedState(btn, '✅ Copiado', 'Copiar link');
                    } catch (e) {
                        input.select();
                        input.setSelectionRange(0, 99999);
                        document.execCommand('copy');
                        setCopiedState(btn, '✅ Copiado', 'Copiar link');
                    }
                };
                wrapper.appendChild(btn);
            }
            btn.style.display = isEnabled('copyLink') ? '' : 'none';
        }

        return {
            id: 'copyLink',
            name: 'SMART BUS - Copiar Link',
            defaultOn: true,

            init() {
                garantirEstilo();
                observer = new MutationObserver(moverBotaoCopiarLink);
                observer.observe(document.body, { childList: true, subtree: true });
                moverBotaoCopiarLink();
            },

            destroy() {
                if (observer) {
                    observer.disconnect();
                    observer = null;
                }
                document.querySelector('.smart-copy-btn')?.remove();
            }
        };
    }

    // =========================================================================
    // MÓDULO — Fast Loading (esconde a rodinha e a camada cinza de carregamento)
    // Roda já no document-start. Ao desligar, devolve o visual original.
    // =========================================================================
    function criarModuloFastLoading() {
        const SPINNER = 'i.fas.fa-spin.fa-circle-notch';
        const PROPS = ['display', 'visibility', 'opacity', 'pointer-events'];

        let observer = null;
        let aoClicar = null;
        const esperas = new Set();
        const mexidos = new Map(); // elemento -> estilos originais

        function guardar(el) {
            if (mexidos.has(el)) return;
            const orig = {};
            for (const p of PROPS) {
                orig[p] = [el.style.getPropertyValue(p), el.style.getPropertyPriority(p)];
            }
            mexidos.set(el, orig);
        }

        function esconder(el, props) {
            guardar(el);
            for (const [p, v] of props) el.style.setProperty(p, v, 'important');
        }

        function encontrarOverlay(spinner) {
            let el = spinner.parentElement;
            let nivel = 0;
            while (el && el !== document.body && nivel < 10) {
                const r = el.getBoundingClientRect();
                const pos = getComputedStyle(el).position;
                const cobreTela = r.width >= innerWidth * 0.65 && r.height >= innerHeight * 0.45;
                if (cobreTela && (pos === 'fixed' || pos === 'absolute')) {
                    esconder(el, [['opacity', '0'], ['visibility', 'hidden'], ['pointer-events', 'none']]);
                    break;
                }
                el = el.parentElement;
                nivel++;
            }
        }

        function esconderSpinner() {
            for (const s of document.querySelectorAll(SPINNER)) {
                esconder(s, [['display', 'none'], ['visibility', 'hidden'], ['opacity', '0'], ['pointer-events', 'none']]);
                encontrarOverlay(s);
            }
            // Esquece elementos que já saíram da página.
            for (const el of mexidos.keys()) if (!el.isConnected) mexidos.delete(el);
        }

        function agendar(...tempos) {
            requestAnimationFrame(esconderSpinner);
            for (const ms of tempos) {
                const id = setTimeout(() => { esperas.delete(id); esconderSpinner(); }, ms);
                esperas.add(id);
            }
        }

        function iniciarObserver() {
            if (!observer) return;
            if (!document.documentElement) { requestAnimationFrame(iniciarObserver); return; }
            observer.observe(document.documentElement, {
                childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style']
            });
            esconderSpinner();
        }

        return {
            id: 'fast_loading',
            name: 'SMART BUS - Fast Loading',
            defaultOn: true,

            init() {
                if (window.top !== window) return; // equivalente ao @noframes do script original
                if (location.hostname !== 'prod-guanabara-frontoffice-smartbus.smarttravelit.com') return;
                observer = new MutationObserver(muts => {
                    for (const m of muts) {
                        if ((m.type === 'childList' && m.addedNodes.length) ||
                            (m.type === 'attributes' && m.attributeName === 'class')) {
                            esconderSpinner();
                            return;
                        }
                    }
                });
                iniciarObserver();
                agendar(0, 10, 25, 50, 100, 200);

                // O spinner costuma aparecer logo depois do clique no horário.
                aoClicar = () => agendar(0, 5, 15, 30, 50);
                document.addEventListener('click', aoClicar, true);
            },

            destroy() {
                observer?.disconnect();
                observer = null;
                if (aoClicar) document.removeEventListener('click', aoClicar, true);
                aoClicar = null;
                for (const id of esperas) clearTimeout(id);
                esperas.clear();
                for (const [el, orig] of mexidos) {
                    for (const p of PROPS) {
                        const [v, prio] = orig[p];
                        if (v) el.style.setProperty(p, v, prio); else el.style.removeProperty(p);
                    }
                }
                mexidos.clear();
            }
        };
    }

    // =========================================================================
    // MÓDULO — Horário + Serviço (+ Print de Poltronas)
    // =========================================================================
    function criarModuloHorarioServico() {

        let observer = null;
        let interval = null;
        let style = null;

        const TEXTO_BOTAO = "Print poltronas";
        const COR_BOTAO = "darkred";

        const normalizar = t => (t || "").replace(/\s+/g, "").toUpperCase();

        function criarSpan(texto, cor) {
            const s = document.createElement("span");
            s.textContent = texto;
            if (cor) s.style.color = cor;
            return s;
        }

        // Sobe a partir do título até o card do mapa, parando ANTES do bloco
        // que também contém o card de TARIFAS (não depende de ter poltronas livres)
        function acharMapa(titulo) {
            const ehLimite = el =>
                el === document.body ||
                el.tagName === "APP-SERVICEROW" ||
                /TARIFAS|SEGURO OPCIONAL|ESCOLHA UMA TARIFA/i.test(el.textContent || "");

            let el = titulo.closest(".seat-map-route") || titulo;
            while (el.parentElement && !ehLimite(el.parentElement)) {
                el = el.parentElement;
            }
            return el;
        }

        function feedback(btn, msg, erro = false) {
            btn.textContent = msg;
            btn.style.background = erro ? "#dc2626" : "#16a34a";
            setTimeout(() => {
                btn.textContent = TEXTO_BOTAO;
                btn.style.background = COR_BOTAO;
                btn.disabled = false;
            }, 1800);
        }

        function nomeArquivo(titulo, horario) {
            const rota = ((titulo.innerText || "").split("\n")[0] || "")
                .replace(/TRECHO\s*:/i, "")
                .normalize("NFD").replace(/[̀-ͯ]/g, "")
                .replace(/[^A-Za-z0-9]+/g, "-")
                .replace(/^-|-$/g, "");
            return `poltronas_${rota}_${horario.replace(":", "h")}.png`;
        }

        // Cor de fundo efetiva (sobe até 3 níveis se for transparente)
        function fundo(win, el) {
            for (let i = 0; el && i < 4; i++, el = el.parentElement) {
                const m = win.getComputedStyle(el).backgroundColor.match(/\d+/g);
                if (m && !(m.length === 4 && +m[3] === 0)) return m.map(Number);
            }
            return null;
        }

        function prepararClone(doc) {
            const win = doc.defaultView;

            // percorre só o mapa clonado, não a página inteira
            const raiz = doc.querySelector("[data-tm-mapa]") || doc.body;

            raiz.querySelectorAll("*").forEach(el => {

                // Botão de print some
                if (el.classList.contains("tm-print-btn")) {
                    el.style.visibility = "hidden";
                    return;
                }

                // Compara só o texto PRÓPRIO do elemento
                const proprio = normalizar(
                    [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.nodeValue).join("") ||
                    el.value || ""
                );

                // "SEM ASSENTO" + botão "+": esconde o grupo inteiro
                if (proprio === "SEMASSENTO") {
                    let alvo = el.closest("button, a, [role=button]") || el;
                    while (
                        alvo.parentElement &&
                        normalizar(alvo.parentElement.textContent).startsWith("SEMASSENTO") &&
                        normalizar(alvo.parentElement.textContent).length < 25
                    ) {
                        alvo = alvo.parentElement;
                    }
                    alvo.style.visibility = "hidden";
                    return;
                }

                // "Exibir legenda" / "Ocultar legenda"
                if (proprio === "EXIBIRLEGENDA" || proprio === "OCULTARLEGENDA") {
                    (el.closest("button, a, [role=button]") || el).style.visibility = "hidden";
                    return;
                }

                // Poltronas vermelhas (ocupadas) sem número
                if (!el.children.length && /^\d{1,2}$/.test(el.textContent.trim())) {
                    const c = fundo(win, el);
                    if (c && c[0] > 180 && c[1] < 130 && c[2] < 130) {
                        el.style.color = "transparent";
                        el.style.textShadow = "none";
                    }
                }
            });
        }

        // Carrega o html2canvas sob demanda se o @require não estiver disponível
        const URL_H2C = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
        let promessaH2c = null;

        function pegarHtml2canvas() {
            if (typeof html2canvas !== "undefined") return html2canvas;
            if (window.html2canvas) return window.html2canvas;
            if (typeof unsafeWindow !== "undefined" && unsafeWindow.html2canvas) return unsafeWindow.html2canvas;
            return null;
        }

        function carregarHtml2canvas() {
            const pronto = pegarHtml2canvas();
            if (pronto) return Promise.resolve(pronto);

            if (!promessaH2c) {
                promessaH2c = new Promise((resolve, reject) => {
                    const pagina = typeof unsafeWindow !== "undefined" ? unsafeWindow : window;

                    // Se o site usar AMD (define.amd), o html2canvas não cria a global:
                    // desativa o define só durante o carregamento
                    const defineOriginal = pagina.define;
                    if (defineOriginal?.amd) pagina.define = undefined;
                    const restaurar = () => { if (defineOriginal?.amd) pagina.define = defineOriginal; };

                    const s = document.createElement("script");
                    s.src = URL_H2C;
                    s.onload = () => {
                        restaurar();
                        const f = pegarHtml2canvas();
                        f ? resolve(f) : reject(new Error("h2c"));
                    };
                    s.onerror = () => { restaurar(); reject(new Error("h2c")); };
                    document.head.appendChild(s);
                }).catch(e => {
                    promessaH2c = null; // permite tentar de novo no próximo clique
                    throw e;
                });
            }
            return promessaH2c;
        }

        // Elementos que não entram na conta da largura (botão de print, "SEM ASSENTO", legenda)
        function ignorarNaLargura(el) {
            if (el.closest(".tm-print-btn")) return true;
            const grupo = el.closest("button, a, [role=button]") || el;
            return /SEM\s*ASSENTO|LEGENDA/i.test(grupo.textContent || "");
        }

        // Poltrona = quadradinho visível (com ou sem número)
        function ehAssento(el) {
            const r = el.getBoundingClientRect();
            return r.width >= 20 && r.width <= 90 && Math.abs(r.width - r.height) <= 15;
        }

        // Recorte do print: largura até a traseira do ônibus e altura até a parte
        // de baixo do ônibus, sem nunca cortar o texto do TRECHO / HORÁRIO
        function medirRecorte(mapa, titulo) {
            const rMapa = mapa.getBoundingClientRect();
            const inteiro = { largura: Math.ceil(rMapa.width), altura: Math.ceil(rMapa.height) };
            const limite = rMapa.width * 0.95; // ignora wrappers que ocupam o card inteiro
            let direita = 0;
            let base = 0;

            // 1) Fim do texto do título (TRECHO e HORÁRIO), medido pelo texto real
            const walker = document.createTreeWalker(titulo, NodeFilter.SHOW_TEXT);
            const range = document.createRange();
            let n;
            while ((n = walker.nextNode())) {
                if (!n.nodeValue.trim() || ignorarNaLargura(n.parentElement)) continue;
                range.selectNodeContents(n);
                const r = range.getBoundingClientRect();
                if (r.width > 0) {
                    direita = Math.max(direita, r.right);
                    base = Math.max(base, r.bottom);
                }
            }

            // 2) Faixa vertical do ônibus, a partir das poltronas
            const pecas = [...mapa.querySelectorAll("*")].filter(
                el => !titulo.contains(el) && !ignorarNaLargura(el)
            );
            const assentos = pecas.filter(ehAssento);
            if (!assentos.length) return inteiro;

            const rects = assentos.map(a => a.getBoundingClientRect());
            const faixaTopo = Math.min(...rects.map(r => r.top));
            const faixaBase = Math.max(...rects.map(r => r.bottom));

            // 3) Peças do desenho na altura do ônibus (lataria, traseira, poltronas).
            pecas.forEach(el => {
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0 || r.width >= limite) return;
                if (r.bottom <= faixaTopo || r.top >= faixaBase) return;
                direita = Math.max(direita, r.right);
                base = Math.max(base, r.bottom);
            });

            const MARGEM_LADO = 10;  // respiro depois da traseira
            const MARGEM_BAIXO = 20; // respiro abaixo do ônibus
            return {
                largura: Math.min(inteiro.largura, Math.ceil(direita - rMapa.left + MARGEM_LADO)),
                altura: Math.min(inteiro.altura, Math.ceil(base - rMapa.top + MARGEM_BAIXO))
            };
        }

        async function tirarPrint(btn, titulo, horario) {

            const mapa = acharMapa(titulo);
            if (!mapa) return feedback(btn, "Mapa não encontrado", true);

            btn.disabled = true;
            btn.textContent = "Gerando...";

            const { largura, altura } = medirRecorte(mapa, titulo);
            mapa.setAttribute("data-tm-mapa", "1");

            const gerarBlob = carregarHtml2canvas().then(h2c => h2c(mapa, {
                backgroundColor: "#ffffff",
                width: largura,  // corta logo depois da traseira do ônibus
                height: altura,  // corta logo abaixo do ônibus
                imageTimeout: 1500,
                // não clona/carrega o que está fora do mapa (outras viagens, imagens da página)
                ignoreElements: el =>
                    !mapa.contains(el) && !el.contains(mapa) &&
                    (el.tagName === "APP-SERVICEROW" ||
                     /^(IMG|IFRAME|VIDEO|CANVAS|OBJECT|EMBED)$/.test(el.tagName)),
                scale: 2,
                useCORS: true,
                logging: false,
                // Mexe só na cópia usada pelo print, a tela real não muda
                onclone: doc => prepararClone(doc)
            })).then(c => new Promise(res => c.toBlob(res, "image/png")))
               .finally(() => mapa.removeAttribute("data-tm-mapa"));

            try {
                // Promise direto no ClipboardItem: funciona no Chrome e no Safari
                await navigator.clipboard.write([new ClipboardItem({ "image/png": gerarBlob })]);
                feedback(btn, "✓ Copiado!");
            } catch (e) {
                let blob = null;
                try {
                    blob = await gerarBlob;
                } catch (erro) {
                    console.error("[Print poltronas]", erro);
                    return feedback(btn, erro?.message === "h2c" ? "html2canvas não carregou" : "Erro no print", true);
                }
                if (!blob) return feedback(btn, "Erro no print", true);
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = nomeArquivo(titulo, horario);
                a.click();
                setTimeout(() => URL.revokeObjectURL(a.href), 2000);
                feedback(btn, "✓ Baixado");
            }
        }

        function criarBotao(titulo, horario) {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "tm-print-btn";
            b.textContent = TEXTO_BOTAO;
            b.setAttribute("data-html2canvas-ignore", "true");
            Object.assign(b.style, {
                marginLeft: "300px",
                padding: "8px 12px",
                border: "none",
                borderRadius: "4px",
                background: COR_BOTAO,
                color: "#fff",
                fontSize: "11px",
                fontWeight: "700",
                cursor: "pointer"
            });
            b.addEventListener("click", e => {
                e.preventDefault();
                e.stopPropagation();
                tirarPrint(b, titulo, horario);
            });
            return b;
        }

        function atualizar() {

            document.querySelectorAll("app-servicerow").forEach(servicerow => {

                const titulo = servicerow.querySelector(".seat-map-route h4");
                const horarioCol = servicerow.querySelector(".service-info .service-col-3");
                const servico = servicerow.querySelector(".service-info .service-col-7 span");

                if (!titulo || !horarioCol || !servico) return;

                const textoOriginal = horarioCol.textContent
                    .replace(/\s+/g, " ")
                    .trim();

                const primeiroHorario = (textoOriginal.match(/\d{2}:\d{2}/) || [""])[0];
                const nomeServico = servico.textContent.trim();
                const chave = `${primeiroHorario}|${nomeServico}`;

                // wrap permite a info ir para a linha de baixo
                titulo.style.display = "flex";
                titulo.style.alignItems = "center";
                titulo.style.flexWrap = "wrap";

                // span (não div) por causa do CSS ".seat-map-route h4 > div { display:none }"
                let info = titulo.querySelector(".tm-info");

                if (!info) {

                    info = document.createElement("span");
                    info.className = "tm-info";

                    Object.assign(info.style, {
                        flexBasis: "100%",
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        marginTop: "4px",
                        whiteSpace: "nowrap",
                        fontWeight: "700",
                        fontSize: "inherit",
                        color: "inherit"
                    });

                    titulo.appendChild(info);
                }

                if (info.dataset.chave === chave) return;
                info.dataset.chave = chave;

                // cor do label "TRECHO:" para os labels novos
                const lbl = [...titulo.children].find(
                    c => c !== info && /TRECHO/i.test(c.textContent)
                ) || titulo;
                const corLabel = getComputedStyle(lbl).color;

                info.textContent = "";
                info.append(
                    criarSpan("HORÁRIO:", corLabel),
                    criarSpan(primeiroHorario),
                    criarSpan("|", corLabel),
                    criarSpan(nomeServico),
                    criarBotao(titulo, primeiroHorario)
                );

            });

        }

        return {
            id: "horario-servico",
            name: "SMART BUS - Horário + Serviço",
            defaultOn: true,

            init() {
                style = document.createElement("style");
                style.textContent = `
                    .seat-map-route h4 > div{
                        display:none !important;
                    }
                `;
                document.head.appendChild(style);

                atualizar();

                observer = new MutationObserver(atualizar);
                observer.observe(document.body, { childList: true, subtree: true });

                interval = setInterval(atualizar, 1000);

                // deixa o html2canvas pronto antes do primeiro clique
                setTimeout(() => carregarHtml2canvas().catch(() => {}), 1500);
            },

            destroy() {
                observer?.disconnect();
                observer = null;
                clearInterval(interval);
                interval = null;
                style?.remove();
                style = null;
                document.querySelectorAll(".tm-info").forEach(e => e.remove());
            }
        };
    }

    // =========================================================================
    // MÓDULO — Print da Reserva (itinerário + valores, copia/baixa PNG)
    // =========================================================================
    function criarModuloPrintReserva() {
        const BTN_ID = 'tmm-print-reserva-btn';
        const COMP_ID = 'tmm-print-reserva-composicao';
        const LARGURA = 1150;          // largura total do print (px)
        const LARG_VALORES = 380;      // largura da coluna de valores (px)
        const COR_BOTAO = '#8b0000';   // vermelho escuro (mesmo tom do CADASTRAR)
        const ESCALA = 1.25;           // nitidez: 1 = mais rápido, 2 = mais nítido

        let observer = null;
        let debounceId = null;
        let handleKeydown = null;

        // ---------- Busca de elementos ----------
        function acharElementoPorTexto(texto, raiz = document.body) {
            const walker = document.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
            let n;
            while ((n = walker.nextNode())) {
                if (n.nodeValue.trim() === texto) return n.parentElement;
            }
            return null;
        }

        // Sobe a partir do texto até o maior bloco que não engole as seções vizinhas
        function cardDe(textoInicial, marcadoresVizinhos) {
            let el = acharElementoPorTexto(textoInicial);
            if (!el) return null;
            while (el.parentElement && el.parentElement !== document.body) {
                const txt = el.parentElement.innerText || '';
                if (marcadoresVizinhos.some(m => txt.includes(m))) break;
                el = el.parentElement;
            }
            return el;
        }

        // Sobe de "el" até o filho de um bloco que contém algum marcador (dentro do clone)
        function subirAte(el, limite, marcadores) {
            while (el.parentElement && el.parentElement !== limite.parentElement) {
                const txt = el.parentElement.textContent || '';
                if (marcadores.some(m => txt.includes(m))) return el;
                el = el.parentElement;
            }
            return null;
        }

        function numeroReserva() {
            const rotulo = acharElementoPorTexto('Nro da reserva');
            const m = (rotulo?.parentElement?.innerText || '').match(/\b[A-Z0-9]{5,8}\b/);
            return m ? m[0] : 'reserva';
        }

        // Remove a parte "Pagamentos" do card de valores (no clone)
        function removerPagamentos(card) {
            const t = acharElementoPorTexto('Pagamentos dessa', card) || acharElementoPorTexto('Pagamentos', card);
            if (!t) return card;
            const bloco = subirAte(t, card, ['Valores dessa']);
            if (!bloco) return card;
            const pai = bloco.parentElement;
            let n = bloco;
            while (n) { const prox = n.nextElementSibling; n.remove(); n = prox; }
            let ult = pai.lastElementChild;
            while (ult && !ult.textContent.trim() && ult.tagName !== 'TABLE') {
                const ant = ult.previousElementSibling; ult.remove(); ult = ant;
            }
            return card;
        }

        // ---------- Monta o layout do print ----------
        function montarComposicao() {
            const SERV = 'Serviços dessa', VAL = 'Valores dessa', PASS = 'Passageiros dessa';

            const titulo = cardDe('Visualização da reserva', [SERV, 'Nro da reserva']);
            const resumo = cardDe('Nro da reserva', [SERV, 'Visualização da reserva']);
            const itinerario = cardDe(SERV, [VAL, PASS]);
            const valores = cardDe(VAL, [SERV, PASS]);

            if (!itinerario || !valores) return null;

            const prep = (el) => {
                const c = el.cloneNode(true);
                // tira do print qualquer botão (PRINT, Copiar Trecho, Copiar Dados etc.)
                c.querySelectorAll('button, .tm-copiar-btn, .tm-preencher-area').forEach(b => b.remove());
                // tira a borda tracejada do módulo "Área de clique e copia"
                c.querySelectorAll('[data-copiar-ativo]').forEach(el => {
                    el.style.border = '';
                    el.style.padding = '';
                    el.style.borderRadius = '';
                });
                Object.assign(c.style, {
                    width: 'auto', maxWidth: 'none', flex: 'none',
                    margin: '0', position: 'static', float: 'none'
                });
                return c;
            };

            const comp = document.createElement('div');
            comp.id = COMP_ID;
            Object.assign(comp.style, {
                position: 'absolute',
                top: window.scrollY + 'px',
                left: '0',
                width: LARGURA + 'px',
                padding: '16px',
                boxSizing: 'border-box',
                background: getComputedStyle(document.body).backgroundColor || '#f3f4f6',
                opacity: '0',
                pointerEvents: 'none',
                zIndex: '-1',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px'
            });

            // Cabeçalho: só o resumo (sem o título "Reserva / Visualização da reserva")
            if (resumo) {
                const r = prep(resumo);
                if (titulo && resumo.contains(titulo)) {
                    const t = acharElementoPorTexto('Visualização da reserva', r);
                    const tituloClone = t && subirAte(t, r, ['Nro da reserva']);
                    if (tituloClone) tituloClone.remove();
                }
                comp.appendChild(r);
            }

            const linha = document.createElement('div');
            Object.assign(linha.style, {
                display: 'grid',
                gridTemplateColumns: `1fr ${LARG_VALORES}px`,
                gap: '14px',
                alignItems: 'start'
            });
            linha.appendChild(prep(itinerario));
            linha.appendChild(removerPagamentos(prep(valores)));
            comp.appendChild(linha);

            document.body.appendChild(comp);
            return comp;
        }

        // ---------- Carregamento do html2canvas ----------
        const URL_H2C = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
        let h2cPromise = null;

        // 1º tenta o @require; se não tiver, baixa a biblioteca na hora (só uma vez)
        function obterHtml2canvas() {
            if (typeof html2canvas === 'function') return Promise.resolve(html2canvas);
            const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
            if (typeof w.html2canvas === 'function') return Promise.resolve(w.html2canvas);

            if (!h2cPromise) {
                h2cPromise = new Promise((resolve, reject) => {
                    const s = document.createElement('script');
                    s.src = URL_H2C;
                    s.onload = () => (typeof w.html2canvas === 'function')
                        ? resolve(w.html2canvas)
                        : reject(new Error('html2canvas baixou mas não ficou acessível (falta @grant unsafeWindow?)'));
                    s.onerror = () => reject(new Error('Não consegui baixar o html2canvas (site bloqueou ou sem internet)'));
                    document.head.appendChild(s);
                }).catch(err => { h2cPromise = null; throw err; });
            }
            return h2cPromise;
        }

        // ---------- Captura ----------
        async function gerarCanvas() {
            const h2c = await obterHtml2canvas();
            const comp = montarComposicao();
            if (!comp) throw new Error('Não encontrei as seções da reserva na tela.');
            try {
                return await h2c(comp, {
                    backgroundColor: comp.style.background,
                    scale: ESCALA,
                    useCORS: true,
                    logging: false,
                    imageTimeout: 1500,
                    windowWidth: Math.max(window.innerWidth, LARGURA + 100),
                    // só copia o caminho até a composição (bem mais rápido)
                    ignoreElements: (el) =>
                        el !== document.body &&
                        document.body.contains(el) &&
                        !el.contains(comp) &&
                        !comp.contains(el),
                    onclone: (doc) => {
                        const c = doc.getElementById(COMP_ID);
                        if (c) { c.style.opacity = '1'; c.style.zIndex = '1'; }
                    }
                });
            } finally {
                comp.remove();
            }
        }

        const canvasParaBlob = (canvas) => new Promise(res => canvas.toBlob(res, 'image/png'));

        function baixar(blob, nome) {
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = nome;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 2000);
        }

        function feedback(btn, texto, cor) {
            btn.textContent = texto;
            btn.style.background = cor;
            setTimeout(() => {
                btn.textContent = btn.dataset.label;
                btn.style.background = COR_BOTAO;
            }, 1800);
        }

        async function tirarPrint(e) {
            const btn = document.getElementById(BTN_ID);
            if (!btn) return;
            const nome = `reserva_${numeroReserva()}_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.png`;
            btn.textContent = 'Capturando...';

            const blobPromise = gerarCanvas().then(canvasParaBlob);

            try {
                if (e.shiftKey || !navigator.clipboard || typeof ClipboardItem === 'undefined') {
                    baixar(await blobPromise, nome);
                    feedback(btn, '✔ Baixado', '#2e7d32');
                } else {
                    // ClipboardItem com Promise mantém o "gesto do usuário" válido no Chrome
                    await navigator.clipboard.write([new ClipboardItem({ 'image/png': blobPromise })]);
                    feedback(btn, '✔ Copiado!', '#2e7d32');
                }
            } catch (err) {
                console.error('[Print Reserva]', err);
                try {
                    baixar(await blobPromise, nome);
                    feedback(btn, '✔ Baixado', '#2e7d32');
                } catch {
                    feedback(btn, '✖ Erro', '#c62828');
                }
            }
        }

        // ---------- Botão (canto superior direito do card Itinerário) ----------
        function criarBotao() {
            const btn = document.createElement('button');
            btn.id = BTN_ID;
            btn.type = 'button';
            btn.dataset.label = 'PRINT';
            btn.textContent = btn.dataset.label;
            btn.title = 'Clique: copia o print | Shift+Clique: baixa PNG | Atalho: Alt+P';
            Object.assign(btn.style, {
                position: 'absolute', top: '14px', right: '48px', zIndex: 10,
                padding: '9px 20px', background: COR_BOTAO, color: '#fff',
                border: 'none', borderRadius: '6px', fontSize: '12px', fontWeight: '700',
                cursor: 'pointer', boxShadow: '0 2px 6px rgba(0,0,0,.2)'
            });
            btn.addEventListener('click', tirarPrint);
            return btn;
        }

        function atualizar() {
            const naReserva = !!acharElementoPorTexto('Visualização da reserva');
            let btn = document.getElementById(BTN_ID);
            if (!naReserva) { btn?.remove(); return; }

            const card = cardDe('Serviços dessa', ['Valores dessa', 'Passageiros dessa']);
            if (!card) return;
            if (btn && card.contains(btn)) return;

            if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
            if (!btn) btn = criarBotao();
            card.appendChild(btn);
        }

        return {
            id: 'print_reserva',
            name: 'SMART BUS - Print da Reserva',
            defaultOn: true,

            init() {
                handleKeydown = (e) => {
                    if (e.altKey && e.key.toLowerCase() === 'p' && document.getElementById(BTN_ID)) {
                        e.preventDefault();
                        tirarPrint({ shiftKey: e.shiftKey });
                    }
                };
                document.addEventListener('keydown', handleKeydown);

                observer = new MutationObserver((muts) => {
                    // ignora mudanças causadas pela composição temporária do print
                    if (muts.every(m => [...m.addedNodes, ...m.removedNodes].every(n => n.id === COMP_ID))) return;
                    clearTimeout(debounceId);
                    debounceId = setTimeout(atualizar, 400);
                });
                observer.observe(document.body, { childList: true, subtree: true });

                atualizar();
            },

            destroy() {
                observer?.disconnect();
                observer = null;

                clearTimeout(debounceId);
                debounceId = null;

                if (handleKeydown) document.removeEventListener('keydown', handleKeydown);
                handleKeydown = null;

                document.getElementById(BTN_ID)?.remove();
                document.getElementById(COMP_ID)?.remove();
            }
        };
    }

    // =========================================================================
    // MÓDULO — Guanabara: Print dos Horários e Remarcações
    // =========================================================================
    function criarModuloGuanabara() {
        const FONTE_PADRAO = "'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
        const MAX_ITENS_POR_IMAGEM = 15;

        const DICIONARIO_CIDADES = {
            "THE": "TERESINA", "PHB": "PARNAÍBA", "FOR": "FORTALEZA", "SLZ": "SÃO LUÍS",
            "PIC": "PICOS", "FLR": "FLORIANO", "SOB": "SOBRAL", "CJP": "CAJUEIRO DA PRAIA",
            "LCR": "LUÍS CORREIA", "NAT": "NATAL", "REC": "RECIFE", "JPA": "JOÃO PESSOA",
            "MCZ": "MACEIÓ", "AJU": "ARACAJU", "SSA": "SALVADOR", "BEL": "BELÉM",
            "IMP": "IMPERATRIZ", "PNZ": "PETROLINA", "JDO": "JUAZEIRO DO NORTE",
            "CMP": "CAMPO MAIOR", "PIR": "PIRIPIRI", "MOS": "MOSSORÓ", "TBA": "TIANGUÁ",
            "CCM": "CAMOCIM", "CANGA": "RECIFE (CAXANGA)",
            "VARG": "VARGEM GRANDE", "VGE": "VARGEM GRANDE", "GYN": "GOIÂNIA", "BSB": "BRASÍLIA",
            "TJK": "BELO HORIZONTE (TERMINAL JK)", "RIO": "RIO DE JANEIRO", "BHZ": "BELO HORIZONTE",
            "BCN": "BARBACENA", "BTI": "BETIM - MG (TERM ADICIONAL BH)"
        };

        let filaViagensGlobal = [];
        let metadadosViagemGlobal = null;
        let linkAtual = null;
        let intervalHashId = null;
        let intervalBotoesId = null;

        // ---- Utilitários gerais e desenho ----
        function extrairNumero(texto) {
            if (!texto) return 0;
            let limpo = texto.replace(/[^\d,]/g, '').replace(',', '.');
            return parseFloat(limpo) || 0;
        }

        function desenharRetanguloArredondado(ctx, x, y, width, height, radius, fillStyle, strokeStyle = null) {
            ctx.fillStyle = fillStyle;
            ctx.beginPath();
            ctx.moveTo(x + radius, y); ctx.lineTo(x + width - radius, y);
            ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
            ctx.lineTo(x + width, y + height - radius);
            ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
            ctx.lineTo(x + radius, y + height);
            ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
            ctx.lineTo(x, y + radius); ctx.quadraticCurveTo(x, y, x + radius, y);
            ctx.closePath();
            ctx.fill();
            if (strokeStyle) {
                ctx.strokeStyle = strokeStyle;
                ctx.lineWidth = 1.5;
                ctx.stroke();
            }
        }

        function limparCidade(nome) {
            if (!nome) return "---";
            let limpo = nome.replace(/\s*\(TERM[^\)]+\)/gi, '').replace(/^[A-Z]+\s*-\s*/i, '').replace(/\s*-\s*[A-Z]{2}(\s|$)/i, '').replace(/\s*\([A-Z]{2}\)/gi, '').trim();
            let partes = limpo.split('(');
            let base = partes[0].trim().toUpperCase();
            let terminal = partes.length > 1 ? " (" + partes[1] : "";
            if (DICIONARIO_CIDADES[base]) base = DICIONARIO_CIDADES[base];
            return (base + terminal).trim();
        }

        // ---- Lógica da tabela de horários e imagem ----
        function capturarTrecho() {
            let origem = document.querySelector('#txt-origem')?.value || "";
            let destino = document.querySelector('#txt-destino')?.value || "";
            if (!origem || !destino) {
                const textoTopo = document.body.innerText.substring(0, 1500);
                const match = textoTopo.match(/de\s+(.*)\s+para\s+(.*?)(?:\n|em |$)/i);
                if (match) { origem = match[1].trim(); destino = match[2].trim(); }
            }

            let isVolta = false;
            let abasAtivas = document.querySelectorAll('.active, .current, .selected');
            for (let i = 0; i < abasAtivas.length; i++) {
                let txtAba = abasAtivas[i].innerText.toUpperCase();
                if (txtAba.includes('VOLTA') && !txtAba.includes('IDA E VOLTA') && !txtAba.includes('IDA E RETORNO')) {
                    isVolta = true; break;
                }
            }

            if (document.body.innerText.toUpperCase().includes('ESCOLHA SUA VOLTA') ||
                document.body.innerText.toUpperCase().includes('TRECHO DE VOLTA') ||
                document.body.innerText.toUpperCase().includes('SELECIONE A VOLTA')) {
                isVolta = true;
            }

            if (origem && destino) {
                origem = limparCidade(origem);
                destino = limparCidade(destino);

                if (isVolta) return `${destino} ➔ ${origem}`.toUpperCase();
                else return `${origem} ➔ ${destino}`.toUpperCase();
            }
            return "";
        }

        function desenharECopiarImagemTabela(dados) {
            const btn = document.getElementById('btn-copy-william');

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const largura = 850;
            const margem = 30;
            const alturaCartao = 100;
            const espacoEntreCartoes = 15;

            let temConexao = dados.viagens.some(v => v.isConexao);
            let temDireta = dados.viagens.some(v => !v.isConexao);
            let soConexao = temConexao && !temDireta;

            let altura = 115;
            altura += (dados.viagens.length * (alturaCartao + espacoEntreCartoes));
            if (temConexao && temDireta) altura += 50;
            if (soConexao) altura += 50;
            altura += 30;

            canvas.width = largura; canvas.height = altura;

            ctx.fillStyle = '#F4F6F9';
            ctx.fillRect(0, 0, largura, altura);

            ctx.fillStyle = '#283593';
            ctx.fillRect(0, 0, largura, 95);

            let locOrigem = "ORIGEM", locDestino = "DESTINO";
            if (dados.trecho) {
                let pts = dados.trecho.split('➔');
                if (pts.length === 2) {
                    locOrigem = pts[0].trim(); locDestino = pts[1].trim();
                } else if (dados.trecho.includes('->')) {
                    pts = dados.trecho.split('->'); locOrigem = pts[0].trim(); locDestino = pts[1].trim();
                } else {
                    locOrigem = dados.trecho; locDestino = "";
                }
            }

            let tituloTopo = "Passagem de ônibus";
            if (locDestino !== "") {
                tituloTopo += ` de ${locOrigem} para ${locDestino}`;
            } else {
                tituloTopo += ` ${locOrigem}`;
            }

            let extraAviso = (dados.temMaisRestantes || (!dados.temMaisRestantes && soConexao)) ? " (Continuação)" : "";
            if (dados.isPrimeiroLote && !dados.temMaisRestantes) extraAviso = "";
            if (dados.isPrimeiroLote && dados.temMaisRestantes) extraAviso = " (Parte 1)";
            tituloTopo += extraAviso;

            ctx.fillStyle = '#FFFFFF';
            let fSize = 22;
            let maxWidthTitulo = largura - (margem * 2);
            ctx.font = `bold ${fSize}px ${FONTE_PADRAO}`;

            while (ctx.measureText(tituloTopo).width > maxWidthTitulo && fSize > 14) {
                fSize--;
                ctx.font = `bold ${fSize}px ${FONTE_PADRAO}`;
            }

            if (ctx.measureText(tituloTopo).width > maxWidthTitulo) {
                while (ctx.measureText(tituloTopo + "...").width > maxWidthTitulo && tituloTopo.length > 0) {
                    tituloTopo = tituloTopo.slice(0, -1);
                }
                tituloTopo += "...";
            }

            ctx.fillText(tituloTopo, margem, 45);

            ctx.fillStyle = '#FFC107';
            ctx.font = `bold 16px ${FONTE_PADRAO}`;
            ctx.fillText(`📅 ${dados.dataTexto}`, margem, 75);

            let yAtual = 120;

            let desenhouDivisor = false;

            dados.viagens.forEach((v, index) => {
                if (v.isConexao && !desenhouDivisor && (temDireta || index === 0)) {
                    yAtual += 10;
                    ctx.fillStyle = '#CBD5E1';
                    ctx.fillRect(margem, yAtual, largura - (margem * 2), 1);
                    ctx.fillStyle = '#64748B';
                    ctx.font = `bold 12px ${FONTE_PADRAO}`;
                    ctx.textAlign = 'center';
                    ctx.fillText("🔄 OPÇÕES COM TROCA DE VEÍCULO OU MÚLTIPLAS PARADAS", largura / 2, yAtual + 22);
                    ctx.textAlign = 'left';
                    yAtual += 40;
                    desenhouDivisor = true;
                }

                ctx.shadowColor = 'rgba(0,0,0,0.04)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 3;
                desenharRetanguloArredondado(ctx, margem, yAtual, largura - (margem * 2), alturaCartao, 8, '#FFFFFF', '#CBD5E1');
                ctx.shadowColor = 'transparent';

                ctx.font = `bold 12px ${FONTE_PADRAO}`;
                let servicoText = v.servico;
                let pillWidth = ctx.measureText(servicoText).width + 24;
                desenharRetanguloArredondado(ctx, margem + 25, yAtual + 23, pillWidth, 24, 12, '#EEF2FF', '#A5B4FC');
                ctx.fillStyle = '#1E3A8A';
                ctx.textAlign = 'center';
                ctx.fillText(servicoText, margem + 25 + (pillWidth / 2), yAtual + 40);

                ctx.textAlign = 'left';
                ctx.fillStyle = '#475569';
                ctx.font = `600 13px ${FONTE_PADRAO}`;
                ctx.fillText(`💺 ${v.textoPoltronas}`, margem + 30, yAtual + 75);

                let centerCard = largura / 2;

                ctx.fillStyle = '#0F172A';
                ctx.font = `bold 24px ${FONTE_PADRAO}`;
                ctx.textAlign = 'center';
                ctx.fillText(v.saida, centerCard - 120, yAtual + 45);

                ctx.fillStyle = '#64748B';
                ctx.font = `600 11px ${FONTE_PADRAO}`;
                let displayOrigem = locOrigem.length > 20 ? locOrigem.substring(0, 20) + "..." : locOrigem;
                ctx.fillText(displayOrigem, centerCard - 120, yAtual + 65);

                ctx.fillStyle = '#94A3B8'; ctx.font = `bold 18px ${FONTE_PADRAO}`;
                ctx.fillText("➔", centerCard, yAtual + 43);

                ctx.fillStyle = '#0F172A'; ctx.font = `bold 24px ${FONTE_PADRAO}`;
                ctx.fillText(v.chegada, centerCard + 120, yAtual + 45);
                ctx.fillStyle = '#64748B'; ctx.font = `600 11px ${FONTE_PADRAO}`;
                let displayDestino = locDestino.length > 20 ? locDestino.substring(0, 20) + "..." : locDestino;
                ctx.fillText(displayDestino, centerCard + 120, yAtual + 65);

                ctx.textAlign = 'right';
                let displayValor = v.displayValor;
                if (displayValor.toUpperCase() === "ISENTO") {
                    let isentoW = 75;
                    desenharRetanguloArredondado(ctx, largura - margem - 30 - isentoW, yAtual + 35, isentoW, 30, 6, '#F1F5F9', '#CBD5E1');
                    ctx.textAlign = 'center';
                    ctx.fillStyle = '#334155';
                    ctx.font = `bold 13px ${FONTE_PADRAO}`;
                    ctx.fillText("ISENTO", largura - margem - 30 - (isentoW / 2), yAtual + 55);
                } else {
                    let prefixo = "";
                    let valorStr = displayValor;
                    if (displayValor.includes("R$")) {
                        const parts = displayValor.split("R$");
                        prefixo = parts[0].trim();
                        valorStr = "R$ " + parts[1].trim();
                    }

                    ctx.fillStyle = '#64748B'; ctx.font = `600 12px ${FONTE_PADRAO}`;
                    ctx.fillText(prefixo, largura - margem - 30, yAtual + 35);

                    ctx.fillStyle = '#E65100';
                    if (valorStr.includes(",")) {
                        let valParts = valorStr.split(",");
                        let reais = valParts[0];
                        let cents = "," + valParts[1];

                        ctx.font = `bold 14px ${FONTE_PADRAO}`;
                        let centWidth = ctx.measureText(cents).width;
                        ctx.fillText(cents, largura - margem - 30, yAtual + 65);

                        ctx.font = `bold 24px ${FONTE_PADRAO}`;
                        ctx.fillText(reais, largura - margem - 30 - centWidth, yAtual + 65);
                    } else {
                        ctx.font = `bold 24px ${FONTE_PADRAO}`;
                        ctx.fillText(valorStr, largura - margem - 30, yAtual + 65);
                    }
                }
                ctx.textAlign = 'left';

                yAtual += alturaCartao + espacoEntreCartoes;
            });

            canvas.toBlob(async function (blob) {
                try {
                    if (typeof window.ClipboardItem === "undefined") {
                        throw new Error("NAVEGADOR_INCOMPATIVEL");
                    }
                    const item = new ClipboardItem({ "image/png": blob });
                    await navigator.clipboard.write([item]);

                    // NOTIFICAÇÃO QUANDO TEM MUITOS HORÁRIOS
                    if (dados.temMaisRestantes) {
                        if (btn) {
                            btn.style.background = "#E65100";
                            btn.innerHTML = `⚠️ Copiar Restantes (${dados.restantesCount})`;
                            btn.style.pointerEvents = 'auto';
                        }
                        alert("A lista de horários é muito grande! A primeira parte foi copiada.\n\nCole no WhatsApp e depois clique no botão novamente para copiar o restante.");
                    } else {
                        filaViagensGlobal = [];
                        if (btn) {
                            btn.style.background = "#28a745";
                            btn.innerHTML = `✅ Card Copiado!`;
                            setTimeout(() => {
                                btn.style.background = "#303F9F";
                                btn.innerHTML = dados.textoVolta || "📸 Copiar Tabela (Imagem)";
                                btn.style.pointerEvents = 'auto';
                            }, 3000);
                        }
                    }
                } catch (err) {
                    console.error("ERRO COMPLETO DE CÓPIA:", err);
                    alert("⚠️ Detalhe do Erro para Análise:\n\n" + (err.message || err.toString()) + "\n\n(Tire um print para investigarmos)");
                    if (btn) {
                        btn.innerHTML = "❌ Erro! Tente de novo";
                        btn.style.background = "#dc3545";
                        setTimeout(() => {
                            btn.innerHTML = dados.textoVolta || "📸 Copiar Tabela (Imagem)";
                            btn.style.background = "#303F9F";
                            btn.style.pointerEvents = 'auto';
                        }, 4000);
                    }
                }
            }, "image/png");
        }

        function processarLotePendente(isPrimeiroLote) {
            let lote = filaViagensGlobal.splice(0, MAX_ITENS_POR_IMAGEM);
            let temMais = filaViagensGlobal.length > 0;
            let restantes = filaViagensGlobal.length;

            desenharECopiarImagemTabela({
                dataTexto: metadadosViagemGlobal.dataTexto,
                trecho: metadadosViagemGlobal.trecho,
                viagens: lote,
                temMaisRestantes: temMais,
                restantesCount: restantes,
                isPrimeiroLote: isPrimeiroLote,
                textoVolta: "📸 Copiar Tabela (Imagem)"
            });
        }

        function extrairDadosTabela() {
            const elementoData = document.querySelector('.service-date-title, #txt-data-ida-retorno, .active .date-value');
            let dataTexto = elementoData ? elementoData.innerText.trim().toUpperCase() : "DATA";
            dataTexto = dataTexto.replace('EM ', '').replace('COPIAR', '').trim();
            const trecho = capturarTrecho();

            if (filaViagensGlobal.length > 0 && metadadosViagemGlobal &&
                metadadosViagemGlobal.dataTexto === dataTexto && metadadosViagemGlobal.trecho === trecho) {
                processarLotePendente(false);
                return;
            }

            filaViagensGlobal = [];
            const blocosHorario = document.querySelectorAll('.service-col-3');

            let viagensDiretas = [];
            let viagensConexao = [];

            blocosHorario.forEach(bloco => {
                const linha = bloco.closest('.service-row') || bloco.parentElement.parentElement;
                if (!linha) return;

                const b = bloco.querySelectorAll('b');
                const saida = b[0]?.innerText.trim() || "";
                const chegada = b[1]?.innerText.trim() || "";

                if (!saida) return;

                let servico = linha.querySelector('.spn-class')?.innerText.trim() || "CONVENCIONAL";
                const poltTxt = linha.querySelector('.service-availability, [class*="availability"]')?.innerText.replace(/[^0-9]/g, '') || "0";
                const polt = parseInt(poltTxt);

                if (polt <= 0) return;

                let valorNovo = 0;
                const celulas = linha.querySelectorAll('td, .price-family-container, .service-price-family');
                for (let c of celulas) {
                    let txt = c.innerText.toUpperCase();
                    if ((txt.includes('BRL') || txt.includes('R$')) && !txt.includes('INDISPONÍVEL') && !txt.includes('ESGOTADO')) {
                        valorNovo = extrairNumero(txt);
                        if (valorNovo > 0) break;
                    }
                }

                if (valorNovo === 0) return;

                let displayValor = "A partir de R$ " + valorNovo.toLocaleString('pt-BR', { minimumFractionDigits: 2 });

                let textoLinha = linha.innerText.toUpperCase();
                let isConexao = textoLinha.includes('PARADA') || textoLinha.includes('CONEXÃO') || textoLinha.includes('MULTIPLAS') || servico.includes('MULTIPLAS');

                if (isConexao) {
                    if (!servico.includes("MÚLTIPLAS") && !servico.includes("MULTIPLAS")) {
                        servico += " (Conexão)";
                    } else {
                        servico = "CONEXÃO (Múltiplas)";
                    }
                }

                const textoPoltronas = polt === 1 ? "1 vaga" : `${polt} vagas`;
                const viagemObj = { saida, chegada, servico, displayValor, textoPoltronas, isConexao };

                if (isConexao) {
                    viagensConexao.push(viagemObj);
                } else {
                    viagensDiretas.push(viagemObj);
                }
            });

            let viagensFinais = [...viagensDiretas, ...viagensConexao];

            if (viagensFinais.length > 0) {
                filaViagensGlobal = viagensFinais;
                metadadosViagemGlobal = { dataTexto, trecho };
                processarLotePendente(true);
            } else {
                alert("Nenhum horário com vaga disponível encontrado.");
            }
        }

        // ---- Lógica do cartão de remarcação ----
        function espionarTrechosCompletos() {
            try {
                let origem = document.querySelector('#txt-origem')?.value || "";
                let destino = document.querySelector('#txt-destino')?.value || "";
                if (!origem || !destino) {
                    const textoTopo = document.body.innerText.substring(0, 1500);
                    const match = textoTopo.match(/de\s+(.*)\s+para\s+(.*?)(?:\n|em |$)/i);
                    if (match) { origem = match[1].trim(); destino = match[2].trim(); }
                }
                if (origem && destino) {
                    origem = limparCidade(origem);
                    destino = limparCidade(destino);
                    if (origem.length > 2 && destino.length > 2) {
                        sessionStorage.setItem("william_cidades_longas", JSON.stringify({ origem, destino }));
                    }
                }
            } catch (erro) {}
        }

        function capturarDadosConfirmacao() {
            let reserva = { tipo: "CONFERÊNCIA DE REMARCAÇÃO", origem: "---", destino: "---", data: "---", horario: "---", passageiro: "---", servico: "CONVENCIONAL", poltrona: "--" };
            let textoAchatado = document.body.innerText.replace(/\s+/g, ' ').toUpperCase();

            let mData = textoAchatado.match(/(\d{2}\/\d{2}\/\d{4})/);
            if (mData) reserva.data = mData[1];

            let mHora = textoAchatado.match(/(\d{2}:\d{2})\s*(?:-|ÀS|ATÉ)\s*(\d{2}:\d{2})/);
            if (mHora) reserva.horario = `${mHora[1]} às ${mHora[2]}`;

            let elementoPassageiro = document.querySelector('.passenger-name, .lbl-passenger');
            if (elementoPassageiro && elementoPassageiro.innerText.trim() !== '') {
                reserva.passageiro = elementoPassageiro.innerText.trim().toUpperCase();
            } else {
                let mNome = textoAchatado.match(/#\d+\s+([A-ZÀ-ÖØ-öø-ÿ\s]+?)(?=\s+(?:NORMAL|PASSE|IDOSO|ESTUDANTE|BPE|ID\sJOVEM|CRIAN[ÇC]A|GRATUIDADE|CORTESIA|RG|CPF|\d{3}))/);
                if (mNome) reserva.passageiro = mNome[1].trim();
            }

            try {
                const elOrigem = document.querySelector('b.b-search-origin');
                const elDestino = document.querySelector('b.b-search-destination');
                if (elOrigem && elOrigem.innerText) reserva.origem = elOrigem.innerText.trim();
                if (elDestino && elDestino.innerText) reserva.destino = elDestino.innerText.trim();

                const elPoltrona = document.querySelector('.confirm-passenger-list table tbody tr td.td-with-paragraph.text-center');
                if (elPoltrona && elPoltrona.innerText) {
                    let txtPoltrona = elPoltrona.innerText.replace(/\D/g, '');
                    if (txtPoltrona) reserva.poltrona = txtPoltrona;
                }

                const elServico = document.querySelector('.confirm-passenger-list table tbody tr td:nth-child(5)');
                if (elServico && elServico.innerText) {
                    let txtTrechoServico = elServico.innerText.toUpperCase();
                    let mServ = txtTrechoServico.match(/\(((?:EXECUTIVO|LEITO|SEMI\s*LEITO|CONVENCIONAL|DOUBLE|CONFORTO|PREMIUM|PROMO|FLEX)[^()]*)\)/);
                    if (mServ) {
                        reserva.servico = mServ[1].replace(/[^A-Z\s\+]/g, '').trim();
                    } else {
                        if (txtTrechoServico.includes('SEMI LEITO')) reserva.servico = 'SEMI LEITO';
                        else if (txtTrechoServico.includes('LEITO')) reserva.servico = 'LEITO';
                        else if (txtTrechoServico.includes('EXECUTIVO')) reserva.servico = 'EXECUTIVO';
                        else if (txtTrechoServico.includes('CONVENCIONAL')) reserva.servico = 'CONVENCIONAL';
                        else if (txtTrechoServico.includes('CAMA')) reserva.servico = 'CAMA';
                        else if (txtTrechoServico.includes('LEITO PREMIUM')) reserva.servico = 'LEITO PREMIUM';
                        else if (txtTrechoServico.includes('SEMI LEITO +CONFORTO')) reserva.servico = 'SEMI LEITO +CONFORTO';
                    }
                }
            } catch (e) {}

            if (reserva.origem === "---" || reserva.destino === "---") {
                let regexTrecho = /\b([A-ZÀ-ÖØ-öø-ÿ\s\-()]{3,45})\s*(?:->|➔|→|>|[^\w\s()]+)\s*([A-ZÀ-ÖØ-öø-ÿ\s\-()]{3,45})\s*\(([^()]+)\)\s*(\d{1,3})\b/;
                let mTrecho = textoAchatado.match(regexTrecho);
                if (mTrecho) {
                    reserva.origem = mTrecho[1].trim();
                    reserva.destino = mTrecho[2].trim();
                    if (reserva.poltrona === "--") reserva.poltrona = mTrecho[4];
                } else {
                    let mTrechoLongo = textoAchatado.match(/TRECHO\s+([A-ZÀ-ÖØ-öø-ÿ\s]+?)\s*-\s*[A-Z]{2}\s*(?:->|➔|→|>|[^\w\s()]+)\s*([A-ZÀ-ÖØ-öø-ÿ\s]+?)\s*-\s*[A-Z]{2}/);
                    if (mTrechoLongo) {
                        reserva.origem = mTrechoLongo[1].trim();
                        reserva.destino = mTrechoLongo[2].trim();
                    }
                }
            }

            reserva.origem = limparCidade(reserva.origem);
            reserva.destino = limparCidade(reserva.destino);

            try {
                let trechosMemoria = sessionStorage.getItem("william_cidades_longas");
                if (trechosMemoria) {
                    let dadosSalvos = JSON.parse(trechosMemoria);
                    if (dadosSalvos.origem && dadosSalvos.destino && reserva.origem === "---") {
                        reserva.origem = limparCidade(dadosSalvos.origem);
                        reserva.destino = limparCidade(dadosSalvos.destino);
                    }
                }
            } catch (e) {}

            return reserva;
        }

        function gerarImagemBilhete(reserva) {
            const btn = document.getElementById('btn-bilhete-william');

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const largura = 850;
            const margem = 30;
            const altura = 450;
            canvas.width = largura; canvas.height = altura;

            ctx.fillStyle = '#F4F6F8'; ctx.fillRect(0, 0, largura, altura);
            ctx.fillStyle = '#303F9F'; ctx.fillRect(0, 0, largura, 85);

            ctx.fillStyle = '#FFFFFF';
            ctx.font = `600 20px ${FONTE_PADRAO}`;
            ctx.fillText(`🔄 ${reserva.tipo}`, margem, 52);

            let yAtual = 100;

            ctx.shadowColor = 'rgba(0,0,0,0.05)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
            desenharRetanguloArredondado(ctx, margem, yAtual, largura - (margem * 2), 55, 6, '#FFF3F3', '#FFCDD2');
            ctx.shadowColor = 'transparent';

            ctx.fillStyle = '#B71C1C'; ctx.textAlign = 'center';
            ctx.font = `bold 12px ${FONTE_PADRAO}`;
            ctx.fillText("⚠️ ATENÇÃO: Verifique os dados abaixo. O bilhete final só será emitido após confirmação.", largura / 2, yAtual + 32);
            ctx.textAlign = 'left';

            yAtual += 70;

            ctx.shadowColor = 'rgba(0,0,0,0.05)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 3;
            desenharRetanguloArredondado(ctx, margem, yAtual, largura - (margem * 2), 120, 8, '#FFFFFF', '#CBD5E1');
            ctx.shadowColor = 'transparent';

            ctx.fillStyle = '#888888'; ctx.font = `11px ${FONTE_PADRAO}`;
            ctx.fillText('PASSAGEIRO', margem + 25, yAtual + 25);
            ctx.fillStyle = '#333333'; ctx.font = `bold 18px ${FONTE_PADRAO}`;
            let nomeVisual = reserva.passageiro.length > 40 ? reserva.passageiro.substring(0, 40) + "..." : reserva.passageiro;
            ctx.fillText(nomeVisual, margem + 25, yAtual + 48);

            ctx.textAlign = 'right';
            ctx.fillStyle = '#888888'; ctx.font = `11px ${FONTE_PADRAO}`;
            ctx.fillText('CLASSE', largura - margem - 25, yAtual + 25);

            ctx.fillStyle = '#E65100'; ctx.font = `bold 16px ${FONTE_PADRAO}`;
            ctx.fillText(reserva.servico, largura - margem - 25, yAtual + 48);
            ctx.textAlign = 'left';

            ctx.fillStyle = '#EEEEEE'; ctx.fillRect(margem + 20, yAtual + 65, largura - (margem * 2) - 40, 1.5);

            let textoItin = `${reserva.origem}  ➔  ${reserva.destino}`;
            let tamFonteItin = 20;
            let maxLarguraItin = largura - (margem * 2) - 50;
            ctx.font = `bold ${tamFonteItin}px ${FONTE_PADRAO}`;

            while (ctx.measureText(textoItin).width > maxLarguraItin && tamFonteItin > 12) {
                tamFonteItin--;
                ctx.font = `bold ${tamFonteItin}px ${FONTE_PADRAO}`;
            }
            if (ctx.measureText(textoItin).width > maxLarguraItin) {
                while (ctx.measureText(textoItin + "...").width > maxLarguraItin && textoItin.length > 0) {
                    textoItin = textoItin.slice(0, -1);
                }
                textoItin += "...";
            }

            ctx.fillStyle = '#303F9F';
            ctx.fillText(textoItin, margem + 25, yAtual + 102);

            yAtual += 135;

            ctx.shadowColor = 'rgba(0,0,0,0.05)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 3;
            desenharRetanguloArredondado(ctx, margem, yAtual, largura - (margem * 2), 80, 8, '#FFFFFF', '#CBD5E1');
            ctx.shadowColor = 'transparent';

            ctx.fillStyle = '#888888'; ctx.font = `11px ${FONTE_PADRAO}`; ctx.fillText('DATA', margem + 25, yAtual + 28);
            ctx.fillStyle = '#333333'; ctx.font = `bold 18px ${FONTE_PADRAO}`; ctx.fillText(`📅 ${reserva.data}`, margem + 25, yAtual + 55);

            ctx.fillStyle = '#EEEEEE'; ctx.fillRect(margem + 220, yAtual + 18, 2, 44);

            ctx.fillStyle = '#888888'; ctx.font = `11px ${FONTE_PADRAO}`; ctx.fillText('HORÁRIO', margem + 245, yAtual + 28);
            ctx.fillStyle = '#333333'; ctx.font = `bold 18px ${FONTE_PADRAO}`; ctx.fillText(`⏱️ ${reserva.horario}`, margem + 245, yAtual + 55);

            let boxPW = 110; let boxPX = largura - margem - boxPW - 15; let boxPY = yAtual + 12;
            desenharRetanguloArredondado(ctx, boxPX, boxPY, boxPW, 56, 8, '#E8F5E9');
            ctx.textAlign = 'center';
            ctx.fillStyle = '#2E7D32'; ctx.font = `bold 10px ${FONTE_PADRAO}`; ctx.fillText('POLTRONA', boxPX + (boxPW / 2), boxPY + 18);
            ctx.font = `bold 24px ${FONTE_PADRAO}`; ctx.fillText(reserva.poltrona, boxPX + (boxPW / 2), boxPY + 45);
            ctx.textAlign = 'left';

            canvas.toBlob(async function (blob) {
                try {
                    if (typeof ClipboardItem === "undefined") {
                        throw new Error("ClipboardItem_Nao_Suportado_Neste_Navegador");
                    }
                    const item = new ClipboardItem({ "image/png": blob });
                    await navigator.clipboard.write([item]);

                    if (btn) {
                        btn.style.background = "#28a745";
                        btn.innerHTML = `✅ Bilhete Premium Copiado!`;
                        setTimeout(() => {
                            btn.style.background = "#303F9F";
                            btn.innerHTML = "📸 Gerar Prévia de Remarcação";
                            btn.style.pointerEvents = 'auto';
                        }, 3000);
                    }
                } catch (err) {
                    console.error("ERRO COMPLETO DE CÓPIA:", err);
                    alert("⚠️ Detalhe do Erro para Análise:\n\n" + (err.message || err.toString()) + "\n\n(Tire um print para investigarmos)");
                    if (btn) {
                        btn.innerHTML = "❌ Erro! (Veja o aviso)";
                        btn.style.background = "#dc3545";
                        setTimeout(() => {
                            btn.innerHTML = "📸 Gerar Prévia de Remarcação";
                            btn.style.background = "#303F9F";
                            btn.style.pointerEvents = 'auto';
                        }, 4000);
                    }
                }
            }, "image/png");
        }

        function adicionarDrag(btn, acaoClique) {
            let isDragging = false;
            let dragStartX, dragStartY;
            let shiftX, shiftY;

            function onMouseMove(e) {
                if (Math.abs(e.clientX - dragStartX) > 10 || Math.abs(e.clientY - dragStartY) > 10) {
                    isDragging = true;
                    btn.style.bottom = 'auto';
                    btn.style.right = 'auto';
                    btn.style.left = (e.clientX - shiftX) + 'px';
                    btn.style.top = (e.clientY - shiftY) + 'px';
                }
            }

            function onMouseUp() {
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
                btn.style.cursor = 'grab';
            }

            btn.onmousedown = function (e) {
                isDragging = false;
                dragStartX = e.clientX;
                dragStartY = e.clientY;
                shiftX = e.clientX - btn.getBoundingClientRect().left;
                shiftY = e.clientY - btn.getBoundingClientRect().top;
                btn.style.cursor = 'grabbing';
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            };

            btn.onclick = function () {
                if (isDragging) return;

                const txtOriginal = btn.innerHTML;
                btn.innerHTML = "⌛ Copiando...";
                btn.style.pointerEvents = 'none';

                try {
                    acaoClique();
                } catch (erro) {
                    console.error(erro);
                    btn.innerHTML = txtOriginal;
                    btn.style.pointerEvents = 'auto';
                }
            };
        }

        // ---- Loop principal ----
        function gerenciarBotoesETela() {
            espionarTrechosCompletos();

            const temHorarios = document.querySelector('.service-col-3') !== null;

            let textoGeral = document.body.textContent.toUpperCase();
            let isConfirmacaoOuRemarcacao = (textoGeral.includes('TIPO DA OPERAÇÃO') || textoGeral.includes('TIPO DA OPERACAO')) && textoGeral.includes('PASSAGEIRO');

            let btnTabela = document.getElementById('btn-copy-william');
            if (temHorarios && !isConfirmacaoOuRemarcacao) {
                if (!btnTabela) {
                    btnTabela = document.createElement('button');
                    btnTabela.id = 'btn-copy-william';
                    btnTabela.innerHTML = '📸 Copiar Tabela (Imagem)';
                    btnTabela.style = "position:fixed; bottom:20px; right:20px; z-index:999999; padding:10px 18px; background:#303F9F; color:white; border:2px solid #fff; border-radius:8px; font-weight:bold; box-shadow:0 3px 10px rgba(0,0,0,0.25); font-size:14px; cursor:grab;";
                    document.body.appendChild(btnTabela);

                    adicionarDrag(btnTabela, extrairDadosTabela);
                }
                btnTabela.style.display = 'block';

                const elementoData = document.querySelector('.service-date-title, #txt-data-ida-retorno, .active .date-value');
                let curDataTexto = elementoData ? elementoData.innerText.trim().toUpperCase().replace('EM ', '').replace('COPIAR', '').trim() : "";
                let curTrecho = capturarTrecho();

                if (filaViagensGlobal.length > 0 && metadadosViagemGlobal) {
                    if (metadadosViagemGlobal.dataTexto !== curDataTexto || metadadosViagemGlobal.trecho !== curTrecho) {
                        filaViagensGlobal = [];
                        btnTabela.style.background = "#303F9F";
                        btnTabela.innerHTML = '📸 Copiar Tabela (Imagem)';
                        btnTabela.style.pointerEvents = 'auto';
                    }
                }

            } else if (btnTabela) {
                btnTabela.style.display = 'none';
            }

            let btnBilhete = document.getElementById('btn-bilhete-william');
            if (isConfirmacaoOuRemarcacao) {
                if (!btnBilhete) {
                    btnBilhete = document.createElement('button');
                    btnBilhete.id = 'btn-bilhete-william';
                    btnBilhete.innerHTML = '📸 Gerar Prévia de Remarcação';
                    btnBilhete.style = "position:fixed; bottom:80px; right:20px; z-index:999999; padding:10px 18px; background:#303F9F; color:white; border:2px solid #fff; border-radius:8px; font-weight:bold; box-shadow:0 3px 10px rgba(0,0,0,0.25); font-size:14px; cursor:grab;";
                    document.body.appendChild(btnBilhete);

                    adicionarDrag(btnBilhete, () => {
                        gerarImagemBilhete(capturarDadosConfirmacao());
                    });
                }
                btnBilhete.style.display = 'block';
            } else if (btnBilhete) {
                btnBilhete.style.display = 'none';
            }
        }

        return {
            id: 'guanabara_print_horarios',
            name: 'SMART BUS - Print dos horarios e remarcacoes',
            defaultOn: true,

            init() {
                filaViagensGlobal = [];
                metadadosViagemGlobal = null;
                linkAtual = window.location.hash;

                intervalHashId = setInterval(() => {
                    if (window.location.hash !== linkAtual) {
                        linkAtual = window.location.hash;
                        let rotaBase = linkAtual.split('?')[0];
                        const rotasRaiz = ['#/', '#/home', '#/dashboard', ''];

                        if (rotasRaiz.includes(rotaBase)) {
                            filaViagensGlobal = [];
                        }
                    }
                }, 1000);

                intervalBotoesId = setInterval(gerenciarBotoesETela, 1500);
            },

            destroy() {
                if (intervalHashId) clearInterval(intervalHashId);
                if (intervalBotoesId) clearInterval(intervalBotoesId);
                intervalHashId = null;
                intervalBotoesId = null;

                document.getElementById('btn-copy-william')?.remove();
                document.getElementById('btn-bilhete-william')?.remove();

                filaViagensGlobal = [];
                metadadosViagemGlobal = null;
            }
        };
    }

    // =========================================================================
    // REGISTRO — ordem em que aparecem no menu do Tampermonkey
    // =========================================================================
    registrarModulo(criarModuloBarrasMensagens(), 'chat');

    registrarModulo(criarModuloFastLoading(), 'smartbus', true);
    registrarModulo(criarModuloSmartbusCopiarClique(), 'smartbus');
    registrarModulo(criarModuloCopiarLink(), 'smartbus');
    registrarModulo(criarModuloHorarioServico(), 'smartbus');
    registrarModulo(criarModuloPrintReserva(), 'smartbus');
    registrarModulo(criarModuloGuanabara(), 'smartbus');

    iniciarTudo();
})();